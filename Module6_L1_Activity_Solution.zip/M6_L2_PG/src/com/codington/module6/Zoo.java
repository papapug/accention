package com.codington.module6;

/**
 * Topic: Inheritance
 *
 * Instructions:
 * 	Zoo class overrides the methods inherited from the interface RidesHosting
 * 	Zoo hosts High Thrill rides.
 * 	The variable zooRide is used to represent different types of rides.
 * 	The zooRide value is 1 if the ride is a Low Thrill ride for Children and 2 if the
 *  ride is a High Thrill ride for teens and adults.
 */

public class Zoo extends Fare implements RidesHosting{


	//TODO 1 - implement RidesHosting interface

	//TODO 2 - Declare a local private integer variable to hold number of animals value and initialize it to zero.
	private int animals = 0;
	//TODO 3 - Declare an array of String to hold animal names and initialize it to empty string.
	String[] animalNames;
	//TODO 4 - Declare an instance of Safari class with private access modifier and assign null value to it.The Safari class will be composed in Zoo class.
	private Safari safari = null;
	//TODO 5 - Declare a local private integer variable to hold zoo ride value and initialize it to zero.
	private int zooRide = 0;
	//TODO 6 -  Create parameterized constructor of Zoo class that takes a double value, service tax as an argument.
	public Zoo(double serviceTax){
		super(serviceTax);
	}
	//TODO 7 - Invoke superclass's constructor  by passing the service tax argument value.
	//TODO 8 - Generate the setters and getters for the instance variables.
	//TODO 9 - override assignRideCategory() method by assigning the high thrill value to the zooRide instance variable.

	//	Hint: use the HIGH_THRILL constant defined in the RideHosting interface.
	/*TODO 10 - override the getRideDetails method and complete its implementation by following below instructions.
	 *TODO 10.a- create a string variable rideDetails and initialize it with null Value
	 *TODO 10.b - Check the value of zooRide,
	 * 			  assign the string "Low Thrill Rides for Children" to rideDetails if the zooRide is a low thrill ride and
	 * 			 assign the string "High Thrill Rides for Teens and Adults" to rideDetails if zooRide is a high thrill ride
	 * TODO 10.c - return the rideDetails.
	 */
	public int getAnimals() {
		return animals;
	}
	public void setAnimals(int animals) {
		this.animals = animals;
	}
	public String[] getAnimalNames() {
		return animalNames;
	}
	public void setAnimalNames(String[] animalNames) {
		this.animalNames = animalNames;
	}
	public Safari getSafari() {
		return safari;
	}
	public void setSafari(Safari safari) {
		this.safari = safari;
	}
	public int getZooRide() {
		return zooRide;
	}
	public void setZooRide(int zooRide) {
		this.zooRide = zooRide;
	}
	@Override
	public void assignRideCategory() {
		// TODO Auto-generated method stub
		zooRide = HIGH_THRILL;
	}
	@Override
	public String getRideDetails() {
		// TODO Auto-generated method stub
		String rideDetails = null;
		if(zooRide == LOW_THRILL){
			rideDetails = "Low Thrill Rides for Children";
		}
		if(zooRide == HIGH_THRILL){
			rideDetails = "High Thrill Rides for Teens and Adults";
		}
//		rideDetails = (zooRide == LOW_THRILL)? "Low Thrill Rides for Children" : "High Thrill Rides for Teens and Adults";
		return rideDetails;
	}

}
