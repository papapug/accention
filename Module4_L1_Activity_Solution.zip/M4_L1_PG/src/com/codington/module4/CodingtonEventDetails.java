package com.codington.module4;

public class CodingtonEventDetails {
	private enum EventLocation{NORTH, SOUTH}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Event event1 = new Event();

		event1.setEventName("Royal Codington Show");
		event1.setDuration(1);
		event1.setLocation(EventLocation.NORTH.name());
		event1.eventDate = ("Wednesday, NOV 25, 2015 at 11:00 hrs");

		Event event2 = new Event();
		event2.setEventName("Science Alive");
		event2.setDuration(2);
		event2.setLocation(EventLocation.SOUTH.name());
		event2.eventDate = ("Wednesday, NOV 25, 2015 at 16:00 hrs");

		System.out.println("Hello Visitors\n");
		System.out.printf("Event Name = %s%n", event1.getEventName());
		System.out.printf("Duration in hours = %s%n", event1.getDuration());
		System.out.printf("Location = %s%n", event1.getLocation());
		System.out.printf("When = %s%n%n", event1.eventDate);

		System.out.printf("Event Name = %s%n", event2.getEventName());
		System.out.printf("Duration in hours = %s%n", event2.getDuration());
		System.out.printf("Location = %s%n", event2.getLocation());
		System.out.printf("When = %s%n", event2.eventDate);

	}

}
