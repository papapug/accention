package com.codington.module7;

/**
 * Topic: Polymorphism in Java
 * CodingtonRideDetails class for displaying information about Rides hosted in Park and Zoo.
 * The code here depicts how a parent class variable can be used to manipulate objects of various subclasses classes
 * also, how it can  invoke methods on an child object without knowing that object�s type.
 * Instructions: Follow TODO instructions given below
 */

public class CodingtonRideDetails {


	//Main method for entry point of CodingtonRideDetails program

	public static void main(String[] args) {

		//TODO 1. Create an instance of Park class and assign its reference to superclass RidesHosting.
		Park parkObj = new Park();
		//TODO 2. Invoke assignRideCategory() method of Park class using superclass reference.
		parkObj.assignRideCategory();
		//TODO 3. Invoke assignRideLocation() method of Park class using superclass reference.
		parkObj.assignRideLocation();
		//TODO 4. Create an instance of Zoo class and assign its reference to superclass RidesHosting.
		Zoo zooObj = new Zoo();
		//TODO 5. Invoke assignRideCategory() method of Zoo class using superclass reference.
		zooObj.assignRideCategory();
		//TODO 6. Invoke assignRideLocation() method of Zoo class using superclass reference.
		zooObj.assignRideLocation();
		//TODO 7.Display rides category of the park by invoking getRideDetails() method of Park class using superclass reference.
		System.out.println("Rides Category of PARK : " +parkObj.getRideDetails());
		//TODO 8.Display rides category of the park by invoking getRideLocation() method of Park class using superclass reference.
		System.out.println("Rides Location of PARK : " +parkObj.getRideLocation());
		//TODO 9.Display rides category of the zoo by invoking getRideDetails() method of Zoo class using superclass reference.
		System.out.println("Rides Category of Zoo : " +zooObj.getRideDetails());
		//TODO 10.Display rides category of the zoo by invoking getRideLocation() method of Zoo class using superclass reference.
		System.out.println("Rides Location of Zoo : " +zooObj.getRideLocation());


	}

}

