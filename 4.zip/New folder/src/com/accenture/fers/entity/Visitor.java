package com.accenture.fers.entity;


import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
/**
 *	Entity class for Visitor
 */
@Entity
//@Table is the the class level annotation.It is used to define the table name for  entity mapping.
@Table(name="Visitor")
public class Visitor  {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	//TODO 1. Specify the  mapping of 'visitorId' with column 'visitorid' using @Column annotation.
	@Column (name="visitorId")
	private int visitorId;
	//TODO 2. Specify the  mapping of 'address' with column 'address' using @Column annotation.
	@Column (name="address")
	private String address;
	//TODO 3. Specify the  mapping of 'userName' with column 'userName' using @Column annotation.
	@Column (name="username")
	private String userName;
	//TODO 4. Specify the  mapping of 'password' with column 'password' using @Column annotation.
	@Column (name="password")
	private String password;
	//TODO 6. Specify the  mapping of 'firstName' with column 'firstName' using @Column annotation.
	@Column (name="firstname")
	private String firstName;
	//TODO 7. Specify the  mapping of 'lastname' with column 'lastname' using @Column annotation.
	@Column (name="lastname")
	private String lastName;
	//TODO 8. Specify the  mapping of 'email' with column 'email' using @Column annotation.
	@Column (name="email")
	private String email;
	//TODO 9. Specify the  mapping of 'phoneNumber' with column 'phonenumber' using @Column annotation.
	@Column (name="phonenumber")
	private String phoneNumber;





  @ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
  @JoinTable(name="eventsignup",joinColumns = { @JoinColumn(name = "visitorId") }, inverseJoinColumns = { @JoinColumn(name = "eventid") })
  private Set<Event> registeredEvents;

  public int getVisitorId() {
  	return visitorId;
  }
  public void setVisitorId(int visitorId) {
  	this.visitorId = visitorId;
  }

  public String getAddress() {
  	return address;
  }
  public void setAddress(String address) {
  	this.address = address;
  }
  public Set<Event> getRegisteredEvents() {
  	return registeredEvents;
  }
  public void setRegisteredEvents(Set<Event> resgisteredEvents) {
  	this.registeredEvents = resgisteredEvents;
  }

  public String getUserName() {
  	return userName;
  }
  public void setUserName(String userName) {
  	this.userName = userName;
  }
  public String getPassword() {
  	return password;
  }
  public void setPassword(String password) {
  	this.password = password;
  }
  public String getFirstName() {
  	return firstName;
  }
  public void setFirstName(String firstName) {
  	this.firstName = firstName;
  }
  public String getLastName() {
  	return lastName;
  }
  public void setLastName(String lastName) {
  	this.lastName = lastName;
  }
  public String getEmail() {
  	return email;
  }
  public void setEmail(String email) {
  	this.email = email;
  }
  public String getPhoneNumber() {
  	return phoneNumber;
  }
  public void setPhoneNumber(String phoneNumber) {
  	this.phoneNumber = phoneNumber;
  }

}
