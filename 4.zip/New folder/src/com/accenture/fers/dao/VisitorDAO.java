package com.accenture.fers.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.Query;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.accenture.fers.entity.Event;
import com.accenture.fers.entity.Visitor;

@Component
public class VisitorDAO {

	private static final Logger LOGGER = Logger.getLogger(VisitorDAO.class);

	@PersistenceContext
	private EntityManager entityManager;

	public VisitorDAO() {

	}

	/**The insertData() method checks for a visitor's username in database.
	 * If username is not found then we need to insert the visitor by calling
	 * entityManager.merge method.
	 * @return
	 * @throws NoResultException
	 * @throws PersistenceException
	 */
	@Transactional
	public boolean insertData(Visitor visitor) throws NoResultException,
			PersistenceException {

		/*
		 *  TODO 1: Create two boolean variables flag and userFound Initialize both to false
		 */
			boolean flag = false, userFound = false;
		/*
		 *
		 * TODO 2:
		 * 1. Create a variable with name userNameQuery and type Query. Initialize it with value
		 *	  returned from entityManager.createQuery() method.
		 *		2. For the createQuery()-> write a JPA query which fetches username from Visitor table
		 */
			Query userNameQuery= entityManager.createQuery("select v.userName from Visitor v");

		/* TODO 3: Create a variable named usernameList and type ArrayList<String>. Initialize it with value
		 *			returned from userNameQuery.getResultList()
		*/
			ArrayList<String> usernameList = (ArrayList <String>)userNameQuery.getResultList();
		/*
		 * TODO 4: Using a foreach loop , iterate through the usernameList and check if the value of username
		 * 		   in current visitor object is already present in the list.
		 * 			If found then assign the value true to userFound variable and break the loop.
		 *
		 */

			for(int x = 0; x <= usernameList.size()-1; x++){
				if(usernameList.get(x).equals(visitor.getUserName())){
					userFound = true;
					break;
				}
			}

		/*
		 * TODO 5: Check if the value of userFound variable is false. IF false then use entityManager.merge()
		 * to insert the visitor object to database.
		 * Assign the flag variable to true.
		 */

			if(!userFound){

				entityManager.merge(visitor);
				flag = true;
			}
		/*
		 * TODO 6: Return flag
		 */

		return flag;
	}

	/**The searchUser() method searches for a username in database by taking parameters username and password.
	 * It is used for authenticating a user. If user exists then the details about the user is populated in
	 * a Visitor object and is returned.
	 * @param username
	 * @param password
	 * @return Visitor
	 * @throws NonUniqueResultException
	 * @throws PersistenceException
	 */
	public Visitor searchUser(String username, String password)
			throws NonUniqueResultException, PersistenceException {

		/*
		 * TODO 1: Create an empty visitor object and initialize it to null
		 */
			Visitor visitor = null;
		/*
		 * TODO 2: Create a query object and assign query for selecting all details from visitor table
		 * where the username and password matches
		 */
			Query obj = entityManager.createQuery("SELECT v from Visitor v where v.userName=:username and v.password=:password");
		/*
		 * TODO 3: In the visitor object execute the above query and fetch the result.If there is an
		 * exception then throw NORESULTFound Exception
		 */

			obj.setParameter("username", username);
			obj.setParameter("password", password);
            try{
            	visitor = (Visitor)obj.getSingleResult();

            }catch(Exception e){
            	System.out.println(e.getMessage());

            	throw e;
			}

		/*
		 * TODO 4: Return the visitor object
		 */

		return visitor;
	}


	@Transactional
	public void registerVisitorToEvent(Visitor visitor, int eventid)
			throws NoResultException, NonUniqueResultException,
			PersistenceException {
		Query query = entityManager
				.createQuery("SELECT e from Event e where e.eventid=:eventid");
		query.setParameter("eventid", eventid);
		Event event = (Event) query.getSingleResult();

		/** Fetch existing registered events of this visitor */

		Visitor v = entityManager.find(Visitor.class, visitor.getVisitorId());

		Set<Event> resgisteredEvents = v.getRegisteredEvents();
		resgisteredEvents.add(event);

		v.setRegisteredEvents(resgisteredEvents);
		entityManager.merge(v);
	}

	public List<Object[]> registeredEvents(Visitor visitor)
			throws NoResultException, PersistenceException {
		Query query = entityManager
				.createNativeQuery(
						"SELECT E1.eventid, E1.name, E1.description, E1.places, E1.duration, E1.eventtype, E2.signupid "
								+ "   FROM Event E1, eventsignup E2 "
								+ "   WHERE E1.eventid = E2.eventid AND E2.visitorid = ? ORDER BY E2.signupid DESC");
		query.setParameter(1, visitor.getVisitorId());
		return (ArrayList<Object[]>) query.getResultList();
	}

	@Transactional
	public int updateVisitor(Visitor visitor) throws PersistenceException {
		int rows = 0;

		Query query = entityManager
				.createQuery("Update Visitor v set v.firstName=:firstname, v.lastName=:lastname, "
						+ " v.userName=:username, v.email=:email,"
						+ " v.phoneNumber=:phonenumber, v.address=:address "
						+ " where v.visitorId=:visitorid  ");
		query.setParameter("firstname", visitor.getFirstName());
		query.setParameter("lastname", visitor.getLastName());
		query.setParameter("username", visitor.getUserName());
		query.setParameter("email", visitor.getEmail());
		query.setParameter("phonenumber", visitor.getPhoneNumber());
		query.setParameter("address", visitor.getAddress());
		query.setParameter("visitorid", visitor.getVisitorId());
		rows = query.executeUpdate();

		if (rows == 0) {
			throw new PersistenceException("Update visitor failed");
		}
		return rows;

	}

	@Transactional
	public int changePassword(Visitor visitor) throws PersistenceException {
		int flag = 0;

		if (matchWithOldPwd(visitor)) {
			flag = 0;

		} else {
			if (visitor.getPassword() != null && visitor.getVisitorId() != 0) {
				Query query = entityManager
						.createQuery("UPDATE Visitor v SET v.password = :password where v.visitorId = :visitorid ");
				query.setParameter("password", visitor.getPassword());
				query.setParameter("visitorid", visitor.getVisitorId());
				flag = query.executeUpdate();
			}

		}

		return flag;
	}

	private boolean matchWithOldPwd(Visitor visitor)
			throws NonUniqueResultException, PersistenceException {
		boolean passwordMatch = false;

		Query query = entityManager
				.createQuery("SELECT v.password FROM Visitor v where v.visitorId = :visitorid");
		query.setParameter("visitorid", visitor.getVisitorId());
		String password = (String) query.getSingleResult();

		if (password.equalsIgnoreCase(visitor.getPassword())) {
			passwordMatch = true;
		}

		return passwordMatch;

	}

	@Transactional
	public void unregisterEvent(Visitor visitor, int eventid)
			throws NonUniqueResultException, PersistenceException {
		Query query = entityManager
				.createQuery("SELECT e from Event e where e.eventid=:eventid");
		query.setParameter("eventid", eventid);
		Event event = (Event) query.getSingleResult();

		/** Fetch existing registered events of this visitor */

		Visitor v = entityManager.find(Visitor.class, visitor.getVisitorId());

		Set<Event> resgisteredEvents = v.getRegisteredEvents();
		resgisteredEvents.remove(event);

		v.setRegisteredEvents(resgisteredEvents);
		entityManager.merge(v);



	}

	public boolean searchVisitor(String username) {
		boolean flag = false;
		Query query = entityManager
				.createQuery("SELECT count(*) from Visitor v where v.userName = :username");
		query.setParameter("username", username);

		Long count = (Long) query.getSingleResult();

		if (count == 1) {
			flag = true;
		}

		return flag;

	}
}
