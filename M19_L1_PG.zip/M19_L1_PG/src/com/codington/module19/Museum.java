package com.codington.module19;

public class Museum {

	// Variables o hold the value of the museum name and its type.
	private String name;
	private String type;

	// Getter and Setters for museum name and type.
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}


}
